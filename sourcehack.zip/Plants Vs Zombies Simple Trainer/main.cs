﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.IO;

namespace Plants_Vs_Zombies_Simple_Trainer
{
    public partial class main : Form
    {
        // Default process name, modified through the textbox
        string pname = "PlantsVsZombies";

        // needed APIs (key checks, process stuff, memory things)
        #region API Things
        [DllImport("User32.dll")]
        private static extern short GetAsyncKeyState(System.Int32 vKey);
        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll", SetLastError = true)]
        static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        public static bool IsKeyPushedDown(System.Windows.Forms.Keys vKey)
        {
            return 0 != (GetAsyncKeyState((int)vKey) & 0x8000);
        }
        public static bool IsKeyPushedDownCharCode(int keycode)
        {
            return 0 != (GetAsyncKeyState(keycode) & 0x8000);
        }

        [Flags]
        public enum ThreadAccess : int
        {
            TERMINATE = (0x0001),
            SUSPEND_RESUME = (0x0002),
            GET_CONTEXT = (0x0008),
            SET_CONTEXT = (0x0010),
            SET_INFORMATION = (0x0020),
            QUERY_INFORMATION = (0x0040),
            SET_THREAD_TOKEN = (0x0080),
            IMPERSONATE = (0x0100),
            DIRECT_IMPERSONATION = (0x0200)
        }

        [DllImport("kernel32.dll")]
        static extern IntPtr OpenThread(ThreadAccess dwDesiredAccess, bool bInheritHandle, uint dwThreadId);
        [DllImport("kernel32.dll")]
        static extern uint SuspendThread(IntPtr hThread);
        [DllImport("kernel32.dll")]
        static extern int ResumeThread(IntPtr hThread);



        private void SuspendProcess(int PID)
        {
            Process proc = Process.GetProcessById(PID);

            if (proc.ProcessName == string.Empty)
                return;

            foreach (ProcessThread pT in proc.Threads)
            {
                IntPtr pOpenThread = OpenThread(ThreadAccess.SUSPEND_RESUME, false, (uint)pT.Id);

                if (pOpenThread == IntPtr.Zero)
                {
                    break;
                }

                SuspendThread(pOpenThread);
            }
        }

        public void ResumeProcess(int PID)
        {
            Process proc = Process.GetProcessById(PID);

            if (proc.ProcessName == string.Empty)
                return;

            foreach (ProcessThread pT in proc.Threads)
            {
                IntPtr pOpenThread = OpenThread(ThreadAccess.SUSPEND_RESUME, false, (uint)pT.Id);

                if (pOpenThread == IntPtr.Zero)
                {
                    break;
                }

                ResumeThread(pOpenThread);
            }
        }
        #endregion

        // all that's needed to enable/disable hack
        public struct HACK
        {
            public int address;
            public byte[] hackcode;
            public byte[] orgcode;
            public bool on;
            public Label lbl; // label to modify
        }

        HACK[] Hacks = new HACK[12];

        // others
        bool ananasON = false;
        bool MarigoldON = false;
        bool zombieMoveSpeedON = false;
        float zombieMoveSpeed = 0;
        bool SunAutoCollectON = false;
        bool SnailSpeedHack = false;

        public main()
        {
            InitializeComponent();
        }// jmp = 5:
        // hackcode = E9 3A 73 2A 00
        // orgcode  = 89 45 5C 8B C6

        // CodecaveCode = 0xB8, 0xB,0x0,0x0,0x0,0x89,0x45,0x5C,0x8B,0xC6,0xE9,0x1F,0x0E,0x91,0xF5

        // this initializes addresses, bytes etc.
        void InitializeHacks()
        {
            HACK NoPlantCooldown = new HACK();
            NoPlantCooldown.address = 0x491E4F;
            NoPlantCooldown.hackcode = new byte[] { 0x90, 0x90, 0x90 };
            NoPlantCooldown.orgcode = new byte[] { 0x8B, 0x47, 0x24 };
            NoPlantCooldown.on = false;
            NoPlantCooldown.lbl = label20;

            HACK InvinciblePlants = new HACK();
            InvinciblePlants.address = 0x540680;
            InvinciblePlants.hackcode = new byte[] { 0x90, 0x90, 0x90, 0x90 };
            InvinciblePlants.orgcode = new byte[] { 0x83, 0x46, 0x40, 0xFC };
            InvinciblePlants.on = false;
            InvinciblePlants.lbl = label21;

            HACK OneShotKill = new HACK();
            OneShotKill.address = 0x541CE4;
            OneShotKill.hackcode = new byte[] { 0xC7, 0x87, 0xC8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x90 };
            OneShotKill.orgcode = new byte[] { 0x89, 0xAF, 0xC8, 0x00, 0x00, 0x00, 0xE8, 0x91, 0xC3, 0xFF,0xFF };
            OneShotKill.on = false;
            OneShotKill.lbl = label22;

            HACK NoFog = new HACK();
            NoFog.address = 0x41831C;
            NoFog.hackcode = new byte[] { 0x90, 0x90, 0x90, 0x90, 0x90, 0x90 };
            NoFog.orgcode = new byte[] { 0xD9, 0x9E, 0xE8, 0x05, 0x00, 0x00 };
            NoFog.on = false;
            NoFog.lbl = label23;

            HACK HungryChomper = new HACK();
            HungryChomper.address = 0x464F0E;
            HungryChomper.hackcode = new byte[] { 0xC7, 0x47, 0x54, 0x00, 0x00, 0x00, 0x00 };
            HungryChomper.orgcode = new byte[] { 0xC7, 0x47, 0x54, 0xA0, 0x0F, 0x00, 0x00 };
            HungryChomper.on = false;
            HungryChomper.lbl = label24;

            HACK UnlimitedLawnmovers = new HACK();
            UnlimitedLawnmovers.address = 0x45C1E5;
            UnlimitedLawnmovers.hackcode = new byte[] { 0x90, 0x90, 0x90 };
            UnlimitedLawnmovers.orgcode = new byte[] { 0xD9, 0x55, 0x08 };
            UnlimitedLawnmovers.on = false;
            UnlimitedLawnmovers.lbl = label25;

            /*
            HACK ZombiesNoMove = new HACK();
            ZombiesNoMove.address = 0x53B443;
            ZombiesNoMove.hackcode = new byte[] { 0x90, 0x90, 0x90 };
            ZombiesNoMove.orgcode = new byte[] { 0xD9, 0x5E, 0x2C };
            ZombiesNoMove.on = false;
            ZombiesNoMove.lbl = label26;
             * */

            HACK ZombiesNoMove = new HACK();
            ZombiesNoMove.address = 0x53B425;
            ZombiesNoMove.hackcode = new byte[] { 0xEB, 0x1F };
            ZombiesNoMove.orgcode = new byte[] { 0x84,0xC0 };
            ZombiesNoMove.on = false;
            ZombiesNoMove.lbl = label26;

            HACK CherryInstantExplode = new HACK();
            CherryInstantExplode.address = 0x466E1C;
            CherryInstantExplode.hackcode = new byte[] { 0x83, 0xE8, 0x32 };
            CherryInstantExplode.orgcode = new byte[] { 0x83, 0xC0, 0xFF };
            CherryInstantExplode.on = false;
            CherryInstantExplode.lbl = label29;


            Hacks[0] = NoPlantCooldown;
            Hacks[1] = InvinciblePlants;
            Hacks[2] = OneShotKill;
            Hacks[3] = NoFog;
            Hacks[4] = HungryChomper;
            Hacks[5] = UnlimitedLawnmovers;
            Hacks[6] = ZombiesNoMove;
            Hacks[7] = CherryInstantExplode;

        }

        // special one because code caves needed
        void AnanasHack()
        {
            int CodeCaveAddress = 0x718168;
            int jmpAddress = 0x470E29;
            byte[] orgcode = new byte[] { 0x89, 0x45, 0x5C, 0x8B, 0xC6 };
            byte[] hackcode = new byte[] { 0xE9, 0x3A, 0x73, 0x2A, 0x0 };
            byte[] CodeCaveCode = new byte[] { 0xB8, 0xB, 0x0, 0x0, 0x0, 0x89, 0x45, 0x5C, 0x8B, 0xC6, 0xE9, 0xB7,0x8C,0xD5,0xFF };

            if (ananasON)
            {
                Trainer.WriteByteArray(pname, CodeCaveAddress, CodeCaveCode);
                Trainer.WriteByteArray(pname, jmpAddress, hackcode);
                label27.ForeColor = Color.Lime;
            }
            else
            {
                Trainer.WriteByteArray(pname, jmpAddress, orgcode);
                label27.ForeColor = Color.Red;
            }
        }

        // process suspending because sometimes it'd crash due to often executed 
        // opcodes which are about to be changed
        void StopPVZ()
        {
            SuspendProcess(Process.GetProcessesByName("PlantsVsZombies")[0].Id);
        }

        void ResumePVZ()
        {
            ResumeProcess(Process.GetProcessesByName("PlantsVsZombies")[0].Id);
        }

        void ActivateHack(int index)
        {
            StopPVZ(); // Anti-Crash
            int index_ = index-4;
            Hacks[index_].on = !Hacks[index_].on;
            if (Hacks[index_].on)
            {
                // this actually activates the hack (writes the needed bytes to the right place)
                Trainer.WriteByteArray(pname, Hacks[index_].address, Hacks[index_].hackcode);
                Hacks[index_].lbl.ForeColor = Color.Lime;
            }
            else
            {
                // same thing but deactivate the hack
                Trainer.WriteByteArray(pname, Hacks[index_].address, Hacks[index_].orgcode);
                Hacks[index_].lbl.ForeColor = Color.Red;
            }
            ResumePVZ();
        }

        // also special because codecave.
        void ZombieCodeInjection()
        {
            if (zombieMoveSpeedON)
            {
                label35.ForeColor = Color.Lime;
                // Code cave
                int CodeCaveAddress = 0x5D11D1; // 20 Bytes 4 free!:)
                int InjectAddress = 0x53B432; // Here normally zombies will move
                byte[] InjectCode = new byte[] { 0xE9,0x9A,0x5D,0x9,0x0,0x90 };
                byte[] CodeCaveCode = new byte[] { 0xD8, 0x25, 0x10, 0x8D, 0x71, 0x0, 0xE9, 0x63, 0xA2, 0xF6, 0xFF, 0xE9, 0x56, 0xA2, 0xF6, 0xFF };
                Trainer.WriteByteArray(pname, InjectAddress, InjectCode);
                Trainer.WriteByteArray(pname, CodeCaveAddress, CodeCaveCode);
            }
            else
            {
                label35.ForeColor = Color.Red;
                int InjectAddress = 0x53B432; // Here normally zombies will move (again)
                byte[] OrgCode = new byte[] { 0xD8,0x64,0x24,0x8,0xEB,0x7 };
                Trainer.WriteByteArray(pname, InjectAddress, OrgCode);
            }
        }

        // this is actually writing to the loaded float to change the speed
        void ApplyZombieMoveSpeed()
        {
            Trainer.WriteFloat(pname, 0x718D10, zombieMoveSpeed);
        }

        // check if keys are down and then activate hacks
        private void chkkeys_Tick(object sender, EventArgs e)
        {
            // Not if we are writing to process name etc.
            if (!textBox1.Focused && !textBox2.Focused)
            {
                #region F1-F12
                int hack = -1;
                if (IsKeyPushedDown(Keys.F1))
                {
                    hack = 0;
                }
                if (IsKeyPushedDown(Keys.F2))
                {
                    hack = 1;
                }
                if (IsKeyPushedDown(Keys.F3))
                {
                    hack = 2;
                }
                if (IsKeyPushedDown(Keys.F4))
                {
                    hack = 3;
                }
                if (IsKeyPushedDown(Keys.F5))
                {
                    hack = 4;
                }
                if (IsKeyPushedDown(Keys.F6))
                {
                    hack = 5;
                }
                if (IsKeyPushedDown(Keys.F7))
                {
                    hack = 6;
                }
                if (IsKeyPushedDown(Keys.F8))
                {
                    hack = 7;
                }
                if (IsKeyPushedDown(Keys.F9))
                {
                    hack = 8;
                }
                if (IsKeyPushedDown(Keys.F10))
                {
                    hack = 9;
                }
                if (IsKeyPushedDown(Keys.F11))
                {
                    hack = 10;
                }
                if (IsKeyPushedDown(Keys.F12))
                {
                    hack = 11;
                }
                #endregion

                if (hack > 3 && hack < 11)
                {
                    // this handles hack toggles
                    ActivateHack(hack);
                }

                #region F1 - F4
                if (hack == 0) // 99999 Suns
                {
                    // 0x729670 +0x868 +0x5578
                    Trainer.WritePointerInteger(pname, 0x729670, new int[] { 0x868, 0x5578 }, 99999);
                }
                if (hack == 1) // 999999 Money
                {
                    Trainer.WritePointerInteger(pname, 0x729670, new int[] { 0x94C, 0x50 }, 99999); // :10
                }
                if (hack == 2) // 9999 Fert
                {
                    Trainer.WritePointerInteger(pname, 0x729670, new int[] { 0x94C, 0x220 }, 9999 + 1000);
                }
                if (hack == 3) // 9999 Bug Spray
                {
                    Trainer.WritePointerInteger(pname, 0x729670, new int[] { 0x94C, 0x224 }, 9999 + 1000);
                }
                #endregion

                if (hack == 11)
                {
                    ananasON = !ananasON;
                    AnanasHack();
                }



                if (IsKeyPushedDown(Keys.C))
                {
                    Hacks[7].on = !Hacks[7].on;
                    if (Hacks[7].on)
                    {
                        Trainer.WriteByteArray(pname, Hacks[7].address, Hacks[7].hackcode);
                        Hacks[7].lbl.ForeColor = Color.Lime;
                    }
                    else
                    {
                        Trainer.WriteByteArray(pname, Hacks[7].address, Hacks[7].orgcode);
                        Hacks[7].lbl.ForeColor = Color.Red;
                    }
                }



                if (IsKeyPushedDown(Keys.A))
                {
                    SunAutoCollectON = !SunAutoCollectON;
                    if (SunAutoCollectON)
                    {
                        label37.ForeColor = Color.Lime;
                        Trainer.WriteByteArray(pname, 0x4342F2, new byte[] { 0xEB, 0x9 });
                    }
                    else
                    {
                        label37.ForeColor = Color.Red;
                        Trainer.WriteByteArray(pname, 0x4342F2, new byte[] { 0x75, 0x9 });
                    }
                    /*
                    SunAutoCollectON = !SunAutoCollectON;
                    if (SunAutoCollectON)
                    {
                        Trainer.WriteInteger(pname, 0x432CA4, 1);
                        label37.ForeColor = Color.Lime;
                    }
                    else
                    {
                        Trainer.WriteInteger(pname, 0x432CA4, 0);
                        label37.ForeColor = Color.Red;
                    }
                     * */
                }

                if (IsKeyPushedDown(Keys.M))
                {
                    MarigoldON = !MarigoldON;
                    int CountOfPlants = Trainer.ReadPointerInteger(pname, 0x729670, new int[] { 0x868, 0xC8 });
                    if (CountOfPlants > 0)
                    {
                        for (int i = 0; i < CountOfPlants; i++)
                        {
                            int BASE = Trainer.ReadPointerInteger(pname, 0x729670, new int[] { 0x868, 0xC4 }) + i * 0x14C;
                            if (Trainer.ReadInteger(pname, BASE + 0x24) == 38) // Marigold plant
                            {
                                // MessageBox.Show(BASE.ToString("X"));
                                if (MarigoldON)
                                {
                                    StopPVZ(); // Anti-Crash
                                    Trainer.WriteInteger(pname, BASE + 0x58, 0);
                                    Trainer.WriteInteger(pname, BASE + 0x5C, 0);
                                    ResumePVZ();
                                    label33.ForeColor = Color.Lime;
                                }
                                else
                                {
                                    StopPVZ(); // Anti-Crash
                                    Trainer.WriteInteger(pname, BASE + 0x5C, 2500); // 2500 = default!
                                    ResumePVZ();
                                    label33.ForeColor = Color.Red;

                                }
                            }
                        }
                    }
                }

                if (IsKeyPushedDown(Keys.Z))
                {
                    try
                    {
                        //string Response = Microsoft.VisualBasic.Interaction.InputBox("Beispieldialogtext", "Titel", "Vorgabeantwort", 0, 0);
                        // Zombie movement speed hack
                        StopPVZ(); // Anti-Crash
                        zombieMoveSpeedON = !zombieMoveSpeedON;
                        ZombieCodeInjection();
                        //ApplyZombieMoveSpeed();
                        ResumePVZ();
                    }
                    catch
                    {
                        //MessageBox.Show("Error.");
                    }
                }

                //}
            }
        }

        // actually just filesize check if it's v1.2.0.1073 ( the right one! )
        void GameVersionOK()
        {
            try
            {
                string filename = Process.GetProcessesByName(pname)[0].MainModule.FileName;
                FileInfo fi = new FileInfo(filename);
                // 'Length' = size in bytes
                if (fi.Length == 3518848)
                {
                    label39.Text = "Version 1.2.0.1073";
                    label39.ForeColor = Color.Lime;
                }
                else if (fi.Length == 3602312)
                {
                    label39.Text = "Version 1.2.0.1093";
                    label39.ForeColor = Color.Lime;
                }
                else
                {
                    label39.Text = "???";
                    label39.ForeColor = Color.Red;
                }
            }
            catch
            {
                label39.Text = "???";
                label39.ForeColor = Color.Red;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            InitializeHacks();
            GameVersionOK();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pname = textBox1.Text;
            GameVersionOK();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            zombieMoveSpeed = Convert.ToSingle(textBox2.Text);
            ApplyZombieMoveSpeed();
        }

    }
    // trainer class which is able to modify processes memory (WriteProcessMemory)
    // thanks to "Cless" from cheatengine forum who provided this one here!!!!!!!
    public class Trainer
    {
        private const int PROCESS_ALL_ACCESS = 0x1F0FFF;
        [DllImport("kernel32")]
        private static extern int OpenProcess(int AccessType, int InheritHandle, int ProcessId);
        [DllImport("kernel32", EntryPoint = "WriteProcessMemory")]
        private static extern byte WriteProcessMemoryByte(int Handle, int Address, ref byte Value, int Size, ref int BytesWritten);
        [DllImport("kernel32", EntryPoint = "WriteProcessMemory")]
        private static extern int WriteProcessMemoryInteger(int Handle, int Address, ref int Value, int Size, ref int BytesWritten);
        [DllImport("kernel32", EntryPoint = "WriteProcessMemory")]
        private static extern float WriteProcessMemoryFloat(int Handle, int Address, ref float Value, int Size, ref int BytesWritten);
        [DllImport("kernel32", EntryPoint = "WriteProcessMemory")]
        private static extern double WriteProcessMemoryDouble(int Handle, int Address, ref double Value, int Size, ref int BytesWritten);


        [DllImport("kernel32", EntryPoint = "ReadProcessMemory")]
        private static extern byte ReadProcessMemoryByte(int Handle, int Address, ref byte Value, int Size, ref int BytesRead);
        [DllImport("kernel32", EntryPoint = "ReadProcessMemory")]
        private static extern int ReadProcessMemoryInteger(int Handle, int Address, ref int Value, int Size, ref int BytesRead);
        [DllImport("kernel32", EntryPoint = "ReadProcessMemory")]
        private static extern float ReadProcessMemoryFloat(int Handle, int Address, ref float Value, int Size, ref int BytesRead);
        [DllImport("kernel32", EntryPoint = "ReadProcessMemory")]
        private static extern double ReadProcessMemoryDouble(int Handle, int Address, ref double Value, int Size, ref int BytesRead);
        [DllImport("kernel32")]
        private static extern int CloseHandle(int Handle);

        [DllImport("user32")]
        private static extern int FindWindow(string sClassName, string sAppName);
        [DllImport("user32")]
        private static extern int GetWindowThreadProcessId(int HWND, out int processId);


        public static string CheckGame(string WindowTitle)
        {
            string result = "";
            checked
            {
                try
                {
                    int Proc;
                    int HWND = FindWindow(null, WindowTitle);
                    GetWindowThreadProcessId(HWND, out Proc);
                    int Handle = OpenProcess(PROCESS_ALL_ACCESS, 0, Proc);
                    if (Handle != 0)
                    {
                        result = "Game is running...";
                    }
                    else
                    {
                        result = "Game is not running...";
                    }
                    CloseHandle(Handle);
                }
                catch
                { }
            }
            return result;
        }
        public static byte ReadByte(string EXENAME, int Address)
        {
            byte Value = 0;
            checked
            {
                try
                {
                    Process[] Proc = Process.GetProcessesByName(EXENAME);
                    if (Proc.Length != 0)
                    {
                        int Bytes = 0;
                        int Handle = OpenProcess(PROCESS_ALL_ACCESS, 0, Proc[0].Id);
                        if (Handle != 0)
                        {
                            ReadProcessMemoryByte(Handle, Address, ref Value, 2, ref Bytes);
                            CloseHandle(Handle);
                        }
                    }
                }
                catch
                { }
            }
            return Value;
        }
        public static int ReadInteger(string EXENAME, int Address)
        {
            int Value = 0;
            checked
            {
                try
                {
                    Process[] Proc = Process.GetProcessesByName(EXENAME);
                    if (Proc.Length != 0)
                    {
                        int Bytes = 0;
                        int Handle = OpenProcess(PROCESS_ALL_ACCESS, 0, Proc[0].Id);
                        if (Handle != 0)
                        {
                            ReadProcessMemoryInteger(Handle, Address, ref Value, 4, ref Bytes);
                            CloseHandle(Handle);
                        }
                    }
                }
                catch
                { }
            }
            return Value;
        }
        public static float ReadFloat(string EXENAME, int Address)
        {
            float Value = 0;
            checked
            {
                try
                {
                    Process[] Proc = Process.GetProcessesByName(EXENAME);
                    if (Proc.Length != 0)
                    {
                        int Bytes = 0;
                        int Handle = OpenProcess(PROCESS_ALL_ACCESS, 0, Proc[0].Id);
                        if (Handle != 0)
                        {
                            ReadProcessMemoryFloat((int)Handle, Address, ref Value, 4, ref Bytes);
                            CloseHandle(Handle);
                        }
                    }
                }
                catch
                { }
            }
            return Value;
        }
        public static double ReadDouble(string EXENAME, int Address)
        {
            double Value = 0;
            checked
            {
                try
                {
                    Process[] Proc = Process.GetProcessesByName(EXENAME);
                    if (Proc.Length != 0)
                    {
                        int Bytes = 0;
                        int Handle = OpenProcess(PROCESS_ALL_ACCESS, 0, Proc[0].Id);
                        if (Handle != 0)
                        {
                            ReadProcessMemoryDouble((int)Handle, Address, ref Value, 8, ref Bytes);
                            CloseHandle(Handle);
                        }
                    }
                }
                catch
                { }
            }
            return Value;
        }

        public static byte ReadPointerByte(string EXENAME, int Pointer, int[] Offset)
        {
            byte Value = 0;
            checked
            {
                try
                {
                    Process[] Proc = Process.GetProcessesByName(EXENAME);
                    if (Proc.Length != 0)
                    {
                        int Bytes = 0;
                        int Handle = OpenProcess(PROCESS_ALL_ACCESS, 0, Proc[0].Id);
                        if (Handle != 0)
                        {
                            foreach (int i in Offset)
                            {
                                ReadProcessMemoryInteger((int)Handle, Pointer, ref Pointer, 4, ref Bytes);
                                Pointer += i;
                            }
                            ReadProcessMemoryByte((int)Handle, Pointer, ref Value, 2, ref Bytes);
                            CloseHandle(Handle);
                        }
                    }
                }
                catch
                { }
            }
            return Value;
        }
        public static int ReadPointerInteger(string EXENAME, int Pointer, int[] Offset)
        {
            int Value = 0;
            checked
            {
                try
                {
                    Process[] Proc = Process.GetProcessesByName(EXENAME);
                    if (Proc.Length != 0)
                    {
                        int Bytes = 0;
                        int Handle = OpenProcess(PROCESS_ALL_ACCESS, 0, Proc[0].Id);
                        if (Handle != 0)
                        {
                            foreach (int i in Offset)
                            {
                                ReadProcessMemoryInteger((int)Handle, Pointer, ref Pointer, 4, ref Bytes);
                                Pointer += i;
                            }
                            ReadProcessMemoryInteger((int)Handle, Pointer, ref Value, 4, ref Bytes);
                            CloseHandle(Handle);
                        }
                    }
                }
                catch
                { }
            }
            return Value;
        }
        public static float ReadPointerFloat(string EXENAME, int Pointer, int[] Offset)
        {
            float Value = 0;
            checked
            {
                try
                {
                    Process[] Proc = Process.GetProcessesByName(EXENAME);
                    if (Proc.Length != 0)
                    {
                        int Bytes = 0;
                        int Handle = OpenProcess(PROCESS_ALL_ACCESS, 0, Proc[0].Id);
                        if (Handle != 0)
                        {
                            foreach (int i in Offset)
                            {
                                ReadProcessMemoryInteger((int)Handle, Pointer, ref Pointer, 4, ref Bytes);
                                Pointer += i;
                            }
                            ReadProcessMemoryFloat((int)Handle, Pointer, ref Value, 4, ref Bytes);
                            CloseHandle(Handle);
                        }
                    }
                }
                catch
                { }
            }
            return Value;
        }
        public static double ReadPointerDouble(string EXENAME, int Pointer, int[] Offset)
        {
            double Value = 0;
            checked
            {
                try
                {
                    Process[] Proc = Process.GetProcessesByName(EXENAME);
                    if (Proc.Length != 0)
                    {
                        int Bytes = 0;
                        int Handle = OpenProcess(PROCESS_ALL_ACCESS, 0, Proc[0].Id);
                        if (Handle != 0)
                        {
                            foreach (int i in Offset)
                            {
                                ReadProcessMemoryInteger((int)Handle, Pointer, ref Pointer, 4, ref Bytes);
                                Pointer += i;
                            }
                            ReadProcessMemoryDouble((int)Handle, Pointer, ref Value, 8, ref Bytes);
                            CloseHandle(Handle);
                        }
                    }
                }
                catch
                { }
            }
            return Value;
        }

        public static void WriteByte(string EXENAME, int Address, byte Value)
        {
            checked
            {
                try
                {
                    Process[] Proc = Process.GetProcessesByName(EXENAME);
                    if (Proc.Length != 0)
                    {
                        int Bytes = 0;
                        int Handle = OpenProcess(PROCESS_ALL_ACCESS, 0, Proc[0].Id);
                        if (Handle != 0)
                        {
                            WriteProcessMemoryByte(Handle, Address, ref Value, 1, ref Bytes);
                        }
                        CloseHandle(Handle);
                    }
                }
                catch
                { }
            }
        }
        public static void WriteInteger(string EXENAME, int Address, int Value)
        {
            checked
            {
                try
                {
                    Process[] Proc = Process.GetProcessesByName(EXENAME);
                    if (Proc.Length != 0)
                    {
                        int Bytes = 0;
                        int Handle = OpenProcess(PROCESS_ALL_ACCESS, 0, Proc[0].Id);
                        if (Handle != 0)
                        {
                            WriteProcessMemoryInteger(Handle, Address, ref Value, 4, ref Bytes);
                        }
                        CloseHandle(Handle);
                    }
                }
                catch
                { }
            }
        }
        public static void WriteFloat(string EXENAME, int Address, float Value)
        {
            checked
            {
                try
                {
                    Process[] Proc = Process.GetProcessesByName(EXENAME);
                    if (Proc.Length != 0)
                    {
                        int Bytes = 0;
                        int Handle = OpenProcess(PROCESS_ALL_ACCESS, 0, Proc[0].Id);
                        if (Handle != 0)
                        {
                            WriteProcessMemoryFloat(Handle, Address, ref Value, 4, ref Bytes);
                        }
                        CloseHandle(Handle);
                    }

                }
                catch
                { }
            }
        }
        public static void WriteDouble(string EXENAME, int Address, double Value)
        {
            checked
            {
                try
                {
                    Process[] Proc = Process.GetProcessesByName(EXENAME);
                    if (Proc.Length != 0)
                    {
                        int Bytes = 0;
                        int Handle = OpenProcess(PROCESS_ALL_ACCESS, 0, Proc[0].Id);
                        if (Handle != 0)
                        {
                            WriteProcessMemoryDouble(Handle, Address, ref Value, 8, ref Bytes);
                        }
                        CloseHandle(Handle);
                    }
                }
                catch
                { }
            }
        }

        public static void WritePointerByte(string EXENAME, int Pointer, int[] Offset, byte Value)
        {
            checked
            {
                try
                {
                    Process[] Proc = Process.GetProcessesByName(EXENAME);
                    if (Proc.Length != 0)
                    {
                        int Handle = OpenProcess(PROCESS_ALL_ACCESS, 0, Proc[0].Id);
                        if (Handle != 0)
                        {
                            int Bytes = 0;
                            foreach (int i in Offset)
                            {
                                ReadProcessMemoryInteger(Handle, Pointer, ref Pointer, 4, ref Bytes);
                                Pointer += i;
                            }
                            WriteProcessMemoryByte(Handle, Pointer, ref Value, 2, ref Bytes);
                        }
                        CloseHandle(Handle);
                    }
                }
                catch
                { }
            }
        }
        public static void WritePointerInteger(string EXENAME, int Pointer, int[] Offset, int Value)
        {
            checked
            {
                try
                {
                    Process[] Proc = Process.GetProcessesByName(EXENAME);
                    if (Proc.Length != 0)
                    {
                        int Handle = OpenProcess(PROCESS_ALL_ACCESS, 0, Proc[0].Id);
                        if (Handle != 0)
                        {
                            int Bytes = 0;
                            foreach (int i in Offset)
                            {
                                ReadProcessMemoryInteger(Handle, Pointer, ref Pointer, 4, ref Bytes);
                                Pointer += i;
                            }
                            WriteProcessMemoryInteger(Handle, Pointer, ref Value, 4, ref Bytes);
                        }
                        CloseHandle(Handle);
                    }
                }
                catch
                { }
            }
        }
        public static void WritePointerFloat(string EXENAME, int Pointer, int[] Offset, float Value)
        {
            checked
            {
                try
                {
                    Process[] Proc = Process.GetProcessesByName(EXENAME);
                    if (Proc.Length != 0)
                    {
                        int Handle = OpenProcess(PROCESS_ALL_ACCESS, 0, Proc[0].Id);
                        if (Handle != 0)
                        {
                            int Bytes = 0;
                            foreach (int i in Offset)
                            {
                                ReadProcessMemoryInteger(Handle, Pointer, ref Pointer, 4, ref Bytes);
                                Pointer += i;
                            }
                            WriteProcessMemoryFloat(Handle, Pointer, ref Value, 4, ref Bytes);
                        }
                        CloseHandle(Handle);
                    }
                }
                catch
                { }
            }
        }
        public static void WritePointerDouble(string EXENAME, int Pointer, int[] Offset, double Value)
        {
            checked
            {
                try
                {
                    Process[] Proc = Process.GetProcessesByName(EXENAME);
                    if (Proc.Length != 0)
                    {
                        int Handle = OpenProcess(PROCESS_ALL_ACCESS, 0, Proc[0].Id);
                        if (Handle != 0)
                        {
                            int Bytes = 0;
                            foreach (int i in Offset)
                            {
                                ReadProcessMemoryInteger(Handle, Pointer, ref Pointer, 4, ref Bytes);
                                Pointer += i;
                            }
                            WriteProcessMemoryDouble(Handle, Pointer, ref Value, 8, ref Bytes);
                        }
                        CloseHandle(Handle);
                    }
                }
                catch
                { }
            }
        }


        public static string ReadStringUntilNULL(string EXENAME, int Address)
        {
            string value = "";
            bool endOfString = false;
            int counter = 0;
            while (!endOfString)
            {
                if (ReadByte(EXENAME, Address + counter) > (byte)0)
                {
                    value += (char)ReadByte(EXENAME, Address + counter);
                }
                else
                {
                    return value;
                }
                counter++;
            }
            return value;
        }

        public static void WriteString(string EXENAME, int Address, string value)
        {
            if (value != null)
            {
                int counter = 0;
                foreach (char chr in value.ToCharArray())
                {
                    Trainer.WriteByte(EXENAME, Address + counter, (byte)chr);
                    counter++;
                }
            }
        }

        public static void WriteByteArray(string EXENAME, int address, byte[] bytes)
        {
            for (int i = 0; i < bytes.Length; i++)
            {
                WriteByte(EXENAME, address + i, bytes[i]);
            }
        }

        public static void WriteNOPs(string EXENAME, int address, int count)
        {
            for (int i = 0; i < count; i++)
            {
                WriteByte(EXENAME, address + i, 0x90);
            }
        }
    }

}
